#include<3048.h>
#include "lcd.h"
#include "time.h"

#define BUTTON_PORT P4
#define BIT0 0x01
#define BIT1 0x02
#define BIT2 0x04
#define BIT3 0x08
#define BIT4 0x10
#define BIT5 0x20
#define BIT6 0x40
#define BIT7 0x80

#define CHANGE_DISPLAY BIT4
#define SETTING BIT5
#define DOWN BIT6
#define UP BIT7

#define TIME 0
#define DATE 1
#define DISPLAY 0
#define SETUP 1
#define BLINK_OFF 0
#define BLINK_ON 1
char c0 = 0,cOld; 						// counter for timer 0
char c1 = 0;							// counter for timer 1

char displayMode = 0, setupMode = 0;	// 0-time 1-date
char mode = 0;
struct time currentTime = {2018,1,1,0,0,0,1}, timeAdjust, timeOld;
char position = 0;						// adjust position in setup mode
char displayFlag = 0;

void int_imia0 (void)
{
    ITU0.TSR.BIT.IMFA = 0;            	//clear interrupt flag
    c0++;
	
    if(c0==40)
	{	
		UpdateTime(&currentTime);
        c0=0;
    }
	if(c0%20 == 0)
	{
		displayFlag = 1;
	}
}
void int_imia1 (void)					// for function 25ms timer
{
	ITU1.TSR.BIT.IMFA = 0; 				// clear interrupt flag
	c1 +=1;
}
char IsValidPress(char pin)
{
	ITU1.TCNT = 0;
	c1 = 0;
	ITU.TSTR.BIT.STR1 = 1; 				// start timer 1;
	while(c1 <= 5)
	{
		if((BUTTON_PORT.DR.BYTE & pin) == pin)	// if button isn't pressed
		{
			ITU.TSTR.BIT.STR1 = 0;		// halted timer 1
			return 0;
		}
	}
	ITU.TSTR.BIT.STR1 = 0;				// halted time 1
	return 1;
}
void timer0_Init()
{
	ITU0.TCR.BIT.CCLR   = 1;       		//timer counter is cleared by GRA
    ITU0.TCR.BIT.TPSC   = 3;      	    //Source clock /8 = 16MHz/8=2MHz
    ITU0.GRA        	= 50000;        //2Mhz/50000=40Hz???25ms
    ITU0.TIER.BIT.IMIEA = 1;       	    //Timer interrupt enable with IMFA flag ( TSR)
}
void timer1_Init()
{
	ITU1.TCR.BIT.CCLR 	= 1; 			//TCNT is cleared by GRA
	ITU1.TCR.BIT.TPSC 	= 3;
    ITU1.GRA        	= 10000;        //2Mhz/10000=200Hz = 5ms duty time
	ITU1.TIER.BIT.IMIEA	= 1;			// enable interrupt compare mode flag A
}

void DisplayDateTime(char mode)
{
	if(mode == TIME )
	{	
		lcdxy(1,1);
		dspTime(currentTime, 3);	
		
	}
	else if(mode == DATE)
	{
		lcdxy(1,1);
		dspDate(currentTime, 3);
	}	
}
void DisplaySetup(char mode, char blink)
{
	lcdxy(1,1);
	if(mode == TIME )
	{
		if(c0 < 20 || blink == BLINK_OFF) 
			dspTime(timeAdjust, 3);
		else
			dspTime(timeAdjust, position);
	}
	else
	{	
		if(c0 < 20 || blink == BLINK_OFF)
			dspDate(timeAdjust,3);
		else
			dspDate(timeAdjust,position);
	}
}
// change display button callback function (Display mode)
void ChangeDisplayCallbackDisplayMode()
{
	timeOld = currentTime;
	cOld = c0;
	unsigned int timePress = 0;
	if(IsValidPress(CHANGE_DISPLAY))
	{	
		while((BUTTON_PORT.DR.BYTE & CHANGE_DISPLAY) != CHANGE_DISPLAY)			//while button are still pressed
		{
			if(c0==0)
				DisplayDateTime(displayMode);									// display every one second
		}
		timePress = SubtractTime(timeOld, currentTime, cOld, c0);
		if(timePress < 500)
		{
			displayMode = 1 - displayMode;
			DisplayDateTime(displayMode);	
		}
			
	}
}

char SettingCallbackDisplayMode()
{
	// setting button callback function (Display mode)
	// return 1 to exit display mode,
	// return 0 to continue run display mode
	unsigned int timePress = 0;
	timeOld = currentTime;		
	cOld = c0;
	if(IsValidPress(SETTING))
	{
		
		while((BUTTON_PORT.DR.BYTE & SETTING) != SETTING)
		{
			if(c0==0)
				DisplayDateTime(displayMode);
		}
		timePress = SubtractTime(timeOld, currentTime, cOld, c0);
		if(timePress < 2000)
		{
			mode = SETUP;
			setupMode = displayMode;
			timeAdjust = currentTime;
			return 1;
		}	
		else
			return 0;
	}
	else
		return 0;
}
void RunDisplayMode()
{
	// Display mode function
	displayFlag = 1;
	while(1)
	{
		if(displayFlag == 1)
		{
			DisplayDateTime(displayMode);				// Display time/date
			displayFlag = 0;
		}
		
		while((BUTTON_PORT.DR.BYTE&0xF0) != 0xF0)	// if any button are pressed
		{
			unsigned char temp = BUTTON_PORT.DR.BYTE&0xF0;
			if((temp != 0xF0 - CHANGE_DISPLAY) && (temp!= 0xF0 - SETTING))	// if neither CHANGE_DISPLAY nor SETTING button was preesed
				break;
			else if((BUTTON_PORT.DR.BYTE & CHANGE_DISPLAY) != CHANGE_DISPLAY)	// else if CHANGE_DISPLAY button was pressed
			{
				ChangeDisplayCallbackDisplayMode();
			}
			else 																// SETTING button was pressed
			{
				if(SettingCallbackDisplayMode() == 1)
				{
					return;
				}
			}
		}
	}
}
char ChangeDisplayCallbackSetupMode()
{
	// CHANGE_DISPLAY button callback function (Setup mode)
	// return 1 to exit setup mode,
	// return 0 to continue run setup mode
	if(IsValidPress(CHANGE_DISPLAY))
	{
		while((BUTTON_PORT.DR.BYTE & CHANGE_DISPLAY) != CHANGE_DISPLAY);
		mode = DISPLAY; // Display time mode
		return 1;
	}
	else
		return 0;
}
char SettingCallbackSetupMode()
{
	// SETTING button callback function (Setup mode)
	// return 1 to exit setup mode,
	// return 0 to continue run setup mode
	unsigned int timePress = 0;
	timeOld = currentTime;
	cOld = c0;
	if(IsValidPress(SETTING))
	{
		while((BUTTON_PORT.DR.BYTE & SETTING) != SETTING);
		timePress = SubtractTime(timeOld,currentTime, cOld, c0);
		if(timePress < 2000)
		{
			position++;
			displayFlag = 1;
			if(position == 2 && setupMode == DATE)
			{
				while(timeAdjust.date > MaximumDaysOfMonth(timeAdjust.year, timeAdjust.month))
					timeAdjust.date--;
				return 0;
			}
				
			if(position == 3)
			{
				mode = DISPLAY;
				if(setupMode == 1)
				{
					timeAdjust.hour = currentTime.hour;
					timeAdjust.minute = currentTime.minute;
					timeAdjust.second = currentTime.second;
				}
				currentTime = timeAdjust;
				return 1;
			}
		}
		else 
			return 0;
	}
	return 0;
}
void UpButtonCallback()
{
	// UP button callback function (Setup mode)
	// increase time/ date by 1 unit at position
	unsigned int timePress = 0;
	timeOld = currentTime;
	cOld = c0;
	if(IsValidPress(UP))
	{
		while((BUTTON_PORT.DR.BYTE & UP) != UP)
		{
			timePress = SubtractTime(timeOld,currentTime, cOld, c0);
			if((timePress >= 500) && ((timePress%100 == 0)))
			{
				IncreaseTime(&timeAdjust, position, setupMode);
				DisplaySetup(setupMode, BLINK_OFF);
			}
		}
		if(timePress < 500)
		{
			IncreaseTime(&timeAdjust, position, setupMode);
			DisplaySetup(setupMode, BLINK_OFF);
		}	
	}
}
void DownButtonCallback()
{
	// DOWN button callback function (Setup mode)
	// decrease time/ date by 1 unit at position
	unsigned int timePress = 0;
	timeOld = currentTime;
	cOld = c0;
	if(IsValidPress(DOWN))
	{
		while((BUTTON_PORT.DR.BYTE & DOWN) != DOWN)
		{
			timePress = SubtractTime(timeOld,currentTime, cOld, c0);
			if((timePress >= 500) && ((timePress%100 == 0)))
			{
				DecreaseTime(&timeAdjust, position, setupMode);
				DisplaySetup(setupMode,BLINK_OFF);
			}
		}
		if(timePress < 500)
		{
			DecreaseTime(&timeAdjust, position, setupMode);
			DisplaySetup(setupMode,BLINK_OFF);
		}	
	}
}
void RunSetupMode()
{
	// setup mode function
	position = 0;
	displayFlag = 1;
	while(1)
	{
		if(displayFlag == 1)
		{
			DisplaySetup(setupMode, BLINK_ON);
			displayFlag = 0;
		}

		// if cancel button was pressed
		while((BUTTON_PORT.DR.BYTE & 0xF0)!= 0xF0)
		{
			
			unsigned char temp = BUTTON_PORT.DR.BYTE & 0xF0;
			if((temp != 0xF0 - CHANGE_DISPLAY) && (temp != 0xF0 - SETTING) && (temp != 0xF0 - UP) && (temp != 0xF0 - DOWN))
				break;
			else if((BUTTON_PORT.DR.BYTE & CHANGE_DISPLAY) != CHANGE_DISPLAY)
			{
				if(ChangeDisplayCallbackSetupMode() == 1)
				{
					return;
				}
			}
			// if setup button was pressed
			
			else if((BUTTON_PORT.DR.BYTE & SETTING) != SETTING)
			{
				if(SettingCallbackSetupMode() == 1)
				{
					return;
				}
				
			}
			
			// if UP button was pressed
			else if((BUTTON_PORT.DR.BYTE & UP) != UP)
			{
				UpButtonCallback();						
			}		
			// if DOWN button was pressed
			else 
			{
				DownButtonCallback();	
			}	
		}	
	}
}
void main()
{
	//Initial time
	
	lcdini();						//LCD Initiate
	timer0_Init();					//Timer 0 Initiate
	timer1_Init();					//Timer 1 Initiate
	
	//BUTTON PORT Configure
	BUTTON_PORT.DDR = 0x00;
	BUTTON_PORT.PCR.BYTE = 0xFF;
	//Display something
	lcdxy(0,0);
	dsp1g("VER 1 QUOC-CUONG");
	
	EI;  							// Enable Interrupt
	ITU.TSTR.BIT.STR0 = 1;          //Start timer0
	while(1)
	{
		if(mode == DISPLAY)
			RunDisplayMode();
		else
			RunSetupMode();
	}
}