#pragma once
#include<3048.h>
#include"time.h"

#define  E_SIG  0x20       //E
#define  RS_SIG 0x10       //RS
#define line1 0x08
#define line2 0x0C

void wait()                 //delay
{
    int t = 500;
    while(t--);
}

void lcdo8(unsigned char d)     //Send 4 bit data d
{
    d=d | E_SIG;                //Set Enable
    P3.DR.BYTE = d;             //out data to bus
    d = d & 0xdf;               //clear Enable
	P3.DR.BYTE = d;             //out data to bus
    wait();                     //delay
}

void lcdini(void)               //LCD Initial
{
	P3.DDR = 0xFF;
	lcdo8(3);  
	wait();
	lcdo8(3); 
	wait();
	lcdo8(3); 
	wait();
	lcdo8(2); 
	wait();
    lcdo8(2); 
	wait();	
	lcdo8(8);
	wait();
	lcdo8(0);      
	wait();
	lcdo8(0x0c);                
	wait();
	lcdo8(0);      
	wait();
	lcdo8(6);                   
	wait();
}

void lcdclr(void)               //clear screen
{
    P3.DR.BYTE = 0;
    lcdo8(0);
    lcdo8(1);                   
    wait();
}

void lcdxy(unsigned char y,unsigned char x) //move cursor to line y, column x+1
{
    P3.DR.BYTE = 0;
	if(y == 0)
		lcdo8(line1);               //line 1 -> y=8  line 2 -> y=0x0c
	if(y == 1)
		lcdo8(line2);
    lcdo8(x);               //x : 0--> 15
    wait();
}
void lcdo4(unsigned char d)     //display character d (hex code))
{
    unsigned dd;
    dd = d;                     
    d = d >> 4;                 
    d = d & 0x0f;               
    d = d | RS_SIG;             
    lcdo8(d);                   
    wait();                    
    dd = dd & 0x0f;            
    dd = dd | RS_SIG;           
    lcdo8(dd);                  
    wait();
}
void dsp1g(char *str)           //display string
{
    int i = 0;                 
    while(str[i] !=0)
    {
        lcdo4(str[i++]);
    }
}
void dspNumber(int number)		// display number 
{	
	if(number == 0)
	{
		lcdo4('0');
		return;
	}
	char i;
	if(number < 0 )
	{
		lcdo4('-');
		number = -number;
	}
	int mod = 1;
	while(number/mod !=0)
	{
		mod *= 10;
	}
	mod /= 10;
	while(mod !=0)
	{
		if(number !=0)
		{
			i = number/mod;
			lcdo4(i + 48);
			number -= mod*i;
		}
		else
		{
			lcdo4('0');
		}
		mod /= 10;
	}
}
void dspTime(struct time t, char position)
{
	// display time t, position parameter (0~2) correspond to the position that empty string "  " is displayed
	// position = 3 -> display all
	if(position!=0)
	{
		if(t.hour == 0)
			dsp1g("00");
		else 
		{
			if(t.hour < 10)
				lcdo4('0');
			dspNumber(t.hour);
		}
	}
	else
		dsp1g("  ");
	lcdo4(':');
	
	if(position !=1)
	{
		if(t.minute == 0)
			dsp1g("00");
		else 
		{
			if(t.minute < 10)
				lcdo4('0');
			dspNumber(t.minute);
		}
	}
	else
		dsp1g("  ");
	lcdo4(':');
	
	if(position != 2)
	{
		if(t.second == 0)
			dsp1g("00");
		else 
		{
			if(t.second < 10)
				lcdo4('0');
			dspNumber(t.second);
		}
	}
	dsp1g("       ");
}

void dspDate(struct time t, char position)
{
	// display date from time struct t, position parameter (0~2) correspond to the position that empty string "  " is displayed
	// position = 3 -> display all
	if(position != 0)
	{
		dspNumber(t.year);
	}
	else
	{
		if(t.year>999)
			dsp1g("    ");
		else if( t.year > 99)
			dsp1g("   ");
		else if( t.year > 9)
			dsp1g("  ");
		else
			dsp1g(" ");	
	}
		
	lcdo4('/');

	if(position != 1)
	{
		if(t.month < 10)
			lcdo4('0');
		dspNumber(t.month);
	}
	else
		dsp1g("  ");
	lcdo4('/');
	
	if(position != 2)
	{
		if(t.date < 10)
			lcdo4('0');
		dspNumber(t.date);		
	}	
	else
		dsp1g("  ");
	lcdo4('(');
	
	switch(t.day)
	{
		case 0: 
			dsp1g("SUN");
			break;
		case 1: 
			dsp1g("MON");
			break;
		case 2: 
			dsp1g("TUE");
			break;
		case 3: 
			dsp1g("WED");
			break;
		case 4: 
			dsp1g("THU");
			break;
		case 5: 
			dsp1g("FRI");
			break;
		case 6: 
			dsp1g("SAT");
			break;			
	}
	dsp1g(")   ");
}

