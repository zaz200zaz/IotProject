#pragma once
static char arr[] = {0,3,2,5,0,3,5,1,4,6,2,4};
struct time
{
	int year;
	char month;
	char date;	
	char hour;
	char minute;
	char second;
	char day;
};

char IsLeapYear(int year)
{
	//return 1 if parameter year is a leap year, else return 0
	return ((year %4 == 0 && year%100 !=0)||(year%400 == 0));
}
char Is31DaysMonth(char month)
{
	//return 1 if parameter month has 31 days. Else return 0
	return (month== 1 || month == 3 || month == 5 || month == 7 || month == 8 || month ==10 || month == 12);
}
char Is30DaysMonth(char month)
{
	//return 1 if parameter month has 30 days. Else return 0
	return (month == 4 || month == 6 || month == 9 || month == 11);
}
char MaximumDaysOfMonth(int year, char month)
{
	// return the maximum days in the (month, year)
	if(Is31DaysMonth(month))
		return 31;
	if(Is30DaysMonth(month))
		return 30;
	if(IsLeapYear(year))
		return 29;
	return 28;
}
char CalcDay(int year, char month, char date)
{
	// Calculate day 
	year-= month < 3;
	return (year + year/4 - year/100 + year/400 + arr[month-1] + date) % 7;
}
void UpdateTime(struct time *t)
{
	// update time t by 1 second 
	if(++t->second == 60)
	{
		t->second = 0;
		if(++t->minute == 60)
		{
			t->minute = 0;
			if(++t->hour == 24)
			{
				t->hour = 0;
				if(++t->date == 1+ MaximumDaysOfMonth(t->year, t->month))
				{
					t->date = 1;
					if(++t->month == 13)
					{
						t->month = 1;
						if(t->year == 9999)
							t->year = 0;
						else
							t->year++;
					}
				}
				t->day = CalcDay(t->year, t->month, t->date);
			}
		}
	}
}

int SubtractTime(struct time t0, struct time t1, char c0, char c1)// t1 - t0
{
	// time(t1, c1) - time(t0,c0) in ms
	if(t1.second >= t0.second)
		return ((t1.second - t0.second)* 1000 + (c1-c0)*25 );
	else
		if(t1.minute>=t0.minute)
			return ((t1.minute-t0.minute)*60000+(t1.second - t0.second)*1000 +(c1-c0)*25);
		else
			if(t1.hour >= t0.hour)
				return ((t1.hour-t0.hour)*3600000+(t1.minute-t0.minute)*60000+(t1.second - t0.second)*1000 +(c1-c0)*25);
			else
				return (3600000+(t1.minute-t0.minute)*60000 + (t1.second - t0.second)*1000 + (c1-c0)*25);
}
void IncreaseTime(struct time *t, char position, char mode) // increase time by 1 unit at specify position 
{
	if(mode == 0)
	{
		if(position == 0)			// If setup mode is TIME	
		{
			if(t->hour == 23)
				t->hour = 0;
			else
				t->hour += 1;
		}
		else if(position == 1)
		{
			if(t->minute == 59)
				t->minute = 0;
			else
				t->minute += 1;
		}	
		else if(position == 2)
		{
			if(t->second == 59)
				t->second = 0;
			else
				t->second += 1;
		}
	}
	else if(mode == 1)				// If setup mode is DATE	
	{
		if(position == 0)
		{
			if(t->year == 9999)
				t->year = 0;
			else
				t->year +=1;
		}
		else if(position == 1)
		{
			if(t->month == 12)
				t->month = 1;
			else
				t->month += 1;
		}
		else if(position == 2)
		{
			if(t->date < MaximumDaysOfMonth(t->year, t->month))
				t->date++;
			else
				t->date = 1;
		}	
		t->day = CalcDay(t->year, t->month, t->date);
	}		
}
void DecreaseTime(struct time *t, char position, char mode) // increase time by 1 unit at specify position 
{
	if(mode == 0)						// If setup mode is TIME						
	{
		if(position == 0)	
		{
			if(t->hour == 0)
				t->hour = 23;
			else
				t->hour -= 1;
		}
		else if(position == 1)
		{
			if(t->minute == 0)
				t->minute = 59;
			else
				t->minute -= 1;
		}	
		else if(position == 2)
		{
			if(t->second == 0)
				t->second = 59;
			else
				t->second -= 1;
		}
	}
	else if(mode == 1)					// If setup mode is DATE					
	{
		if(position == 0)
		{
			if(t->year == 0)
				t->year = 9999;
			else
				t->year -=1;
		}
		else if(position == 1)
		{
			if(t->month == 1)
				t->month = 12;
			else
				t->month -= 1;
		}
		else if(position == 2)
		{
			if( t->date == 1)
				t->date = MaximumDaysOfMonth(t->year, t->month);
			else
				t->date -= 1;
		}	
		t->day = CalcDay(t->year, t->month, t->date);
	}	
}